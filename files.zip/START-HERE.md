# RationalPrince — complete build bundle

Everything for rationalprince.com in one place, ordered by what to do first.

---

## Priority 0 — two fixes that cost you money today

These need no files from this bundle. Do them first.

1. **`/research/strait-of-hormuz-playbook/` returns 404.** Your homepage links
   to it. Every click on your $17 entry product currently lands on an error
   page. The replacement page is in `site/` below.
2. **Every buy button in the catalogue points at `#`.** Nine products, no
   working checkout. Paste your Stan links in.

No amount of SEO outranks a broken checkout.

---

## What's in this bundle

    START-HERE.md          this file
    START-HERE.html        same thing, openable in a browser
    SITE-PLAN.md           full keyword-to-URL map and reasoning
    site/                  five new pages, ready to upload
    briefs-system/         optional: Jekyll setup for publishing briefs

---

## Part 1 — `site/` (do this)

Five indexable pages. Upload preserving folder structure; each is a folder with
`index.html`, so URLs come out clean with no `.html` extension.

    assets/css/rp.css
    research/strait-of-hormuz-playbook/index.html
    energy/oil-price-index/index.html
    energy/market-analysis/index.html
    markets/dow-jones-and-oil/index.html
    sovereign/wealth-funds/index.html
    sitemap.xml                            replaces your current one

Before uploading: open
`research/strait-of-hormuz-playbook/index.html` and replace
`REPLACE-WITH-CHECKOUT-URL` with the real Stan checkout link.

### Why these five

Your whole site is one URL with anchor links. Google ranks one page for one
primary intent, so 88 tracked keywords currently have one place to land. These
five pages give the other clusters somewhere to rank:

| Page | Tracked keywords it targets |
|---|---|
| oil-price-index | ~25 — every Brent, WTI, crude index and oil index term |
| dow-jones-and-oil | 8 — the Dow and futures terms |
| sovereign/wealth-funds | 10 — sovereign fund terms plus central bank gold buying |
| energy/market-analysis | 7 — energy and gas analysis terms |
| strait-of-hormuz-playbook | fixes the 404, carries Product schema |

All five carry FAQPage schema, cross-link to each other, and link back to your
catalogue.

---

## Part 2 — `briefs-system/` (do this second, or skip)

A Jekyll collection that turns published briefs into individual indexable pages
with Article schema and an auto-generated sitemap. Install notes are in
`briefs-system/README-INSTALL.md`.

Two rules: delete any hand-written `sitemap.xml` first, and never add a
`.nojekyll` file.

If you install this, it supersedes the static `sitemap.xml` from Part 1 — the
plugin generates one.

**Note:** the Hormuz pillar page originally in this kit has been removed. It was
written before I read your live site and stated the strait had never been
closed, which contradicts your own reference page. Your homepage covers that
ground correctly already.

---

## Part 3 — after upload

1. Submit `https://rationalprince.com/sitemap.xml` in Search Console.
2. Request indexing on each of the five new URLs individually.
3. Re-check the rank tracker in 3–4 weeks. Not before — nothing will have moved.

---

## Part 4 — tracker cleanup

14 of your 88 tracked keywords are irrelevant to the site and will never rank.
They dilute the report. Full list is in `SITE-PLAN.md`. Ask and I'll strip them.

---

## Part 5 — the rebuilt homepage (`site/index.html`)

A full rebuild of `/`, keeping every word of your existing copy. What changed:

- **Sticky masthead** with navigation to the new reference pages, not just
  in-page anchors.
- **Working catalogue.** The All / Institutional / Foundations filter now
  actually filters (10 lines of vanilla JS, no library). Every buy button
  points at your Stan store instead of `#`.
- **Structured data.** Organization, WebSite, FAQPage covering all seven Hormuz
  questions, and an ItemList of all nine products with prices. This is what
  makes the FAQ eligible for rich results and the products eligible for price
  display.
- **A "From the desk" section** linking to the four open reference pages. That
  internal linking is what passes authority from the homepage to them.
- **Real email form** in place of the plain button.
- Skip link, visible keyboard focus, reduced-motion respected, readable at
  360px.

### Before you upload it

1. Paste your existing GA4 snippet where the comment marks it in `<head>`, or
   you lose analytics.
2. Replace `REPLACE-WITH-BEEHIIV-FORM-URL` in the brief form with your Beehiiv
   embed URL.
3. Swap the nine `https://stan.store/rationalprince` links for direct product
   checkout URLs if you have them. The store link is a working fallback, not the
   ideal — a direct checkout converts better than a storefront.

Back up your current `index.html` before replacing it.

---

## Update — 2 September 2026, second pass

**Real checkout wired in.** Every reference to the Hormuz Playbook now points at
`https://stan.store/rationalprince/p/the-strait-of-hormuz-playbook-` — the buy
button on the homepage, the buy button on the product page, and the `url` inside
the Product schema offer. The Stan listing's banner image is now the `og:image`
on the product page, so the link previews properly when shared. The "11 pages,
instant PDF" detail from your Stan listing has been added to both pages, because
a concrete deliverable converts better than a vague one.

The other eight products still point at the storefront. Send me those eight
direct product URLs and I will wire them the same way.

**`energy/market-analysis/` expanded** to cover the twelve keywords added to the
tracker this round. Three new sections:

- *How to read the weekly crude oil inventory report* — surprise vs consensus,
  Cushing separately, products alongside crude, the five-year range.
- *Natural gas storage is its own report, on its own clock* — injection and
  withdrawal against consensus, the five-year range, regional splits, why
  forecasts are themselves tradable, end-of-season levels.
- *OPEC production, quota and delivery* — announced levels vs delivered barrels,
  and OPEC against non-OPEC supply growth.

Three matching FAQ entries and schema questions added. Title and meta
description rewritten to carry the new intents.

**`energy/oil-price-index/` sharpened** for the six terms added this round.
Two headings rewritten to name the search intent directly ("Brent vs WTI" and
"Contango and backwardation"), three FAQ entries and schema questions added,
title and description updated.

Tracker now at 106 of 125 keywords.

**Link fix.** The "see the Playbook" hyperlink inside the first Hormuz answer has
been removed; the sentence now points readers down the page instead. Every other
internal link across all six pages has been converted from root-relative
(`/energy/...`) to absolute (`https://rationalprince.com/energy/...`). If you
saw a link resolve to `claudeusercontent.com`, that was the file preview
rewriting root-relative paths against its own host — not something in the file
itself. Absolute URLs make that impossible anywhere the file gets previewed.
